const socket = io('http://localhost:8000');

const form = document.getElementById('send-box');
const messageInput = document.getElementById('messagingInput');
const messageContainer = document.querySelector('.container');
var audio = new Audio('ding-sound-246413.mp3');
// Helper function to append messages
const append = (message, position) => {
    const messageElement = document.createElement('div');
    messageElement.innerText = message;
    messageElement.classList.add('message', position);
    messageContainer.append(messageElement);
    if(position == 'left'){
        console.log('sound is playing');
        audio.play();
    }
};

// Prompt the user for a room code and name
const roomCode = prompt('Enter the room code:');
const userName = prompt('Enter your name:');

// Emit event to join a room
socket.emit('join-room', { roomCode, userName });

// Handle events
socket.on('room-joined', () => {
    append(`You joined room: ${roomCode}`, 'right');
});

socket.on('user-joined', (name) => {
    append(`${name} joined the chat`, 'left');
});

socket.on('receive-message', ({ userName, message }) => {
    append(`${userName}: ${message}`, 'left');
});

socket.on('user-left', (name) => {
    append(`${name} has left the chat`, 'left');
});

socket.on('room-error', (error) => {
    alert(error);
});

// Handle message sending
form.addEventListener('submit', (e) => {
    e.preventDefault();
    const message = messageInput.value;
    append(`You: ${message}`, 'right');
    socket.emit('send-message', { roomCode, message });
    messageInput.value = '';
});
