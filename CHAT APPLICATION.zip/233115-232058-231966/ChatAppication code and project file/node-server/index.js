const io = require('socket.io')(8000, {
    cors: {
        origin: 'http://127.0.0.1:5500',
        methods: ['GET', 'POST'],
    },
});

// Store room information
const rooms = {};


//new  connections
io.on('connection', (socket) => {
    // Join a room
    socket.on('join-room', ({ roomCode, userName }) => {
        if (!rooms[roomCode]) {
            rooms[roomCode] = [];
        }

        rooms[roomCode].push({ id: socket.id, name: userName });
        socket.join(roomCode);
        socket.to(roomCode).emit('user-joined', userName);
        socket.emit('room-joined');

        console.log(`${userName} joined room: ${roomCode}`);
    });

    // Handle message sending
    socket.on('send-message', ({ roomCode, message }) => {
        const user = rooms[roomCode]?.find((user) => user.id === socket.id);
        if (user) {
            socket.to(roomCode).emit('receive-message', { userName: user.name, message });
        }
    });

    // Handle user disconnect
    socket.on('disconnect', () => {
        for (const roomCode in rooms) {
            const userIndex = rooms[roomCode].findIndex((user) => user.id === socket.id);
            if (userIndex !== -1) {
                const [user] = rooms[roomCode].splice(userIndex, 1);
                socket.to(roomCode).emit('user-left', user.name);
                console.log(`${user.name} left room: ${roomCode}`);
                break;
            }
        }
    });
});
